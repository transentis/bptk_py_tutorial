# BPTK_Py tutorial

This tutorial repository contains example notebooks, simulation models and scenarios to get started.

It uses an interactive approach to explain you how to work with the Business Prototyping Toolkit for Python.
